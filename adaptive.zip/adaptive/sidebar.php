<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('main-sidebar')) : ?>

	<div class="sidebar-widget">
	
		<h4><?php bloginfo('title'); ?></h4>
		<p><?php bloginfo('description'); ?></p>
		
	</div> <!-- end sidebar-widget -->
	
<?php endif; ?>

				