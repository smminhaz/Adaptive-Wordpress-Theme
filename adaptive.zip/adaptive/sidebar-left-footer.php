<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('left-footer')) : ?>

	<div class="footer-widget span6">
	
		<h4><?php bloginfo('title'); ?></h4>
		<p><?php bloginfo('description'); ?></p>
		
	</div> <!-- end sidebar-widget -->
	
<?php endif; ?>

				