<!-- FOOTER -->
	<footer>
		
		<div class="footer-widget-area">
		
			<div class="container">
			
				<div class="row">
				
					<div class="span6">
						
						<div class="row">
							
							<?php get_sidebar('left-footer'); ?>
							
						</div> <!-- end row -->
						
					</div> <!-- end span6 -->

					<?php get_sidebar('right-footer'); ?>
									
				</div> <!-- end row -->
				
			</div> <!-- end container -->
			
		</div> <!-- end footer-widget-area -->
		
		<div class="copyright-container clearfix">
			
			<div class="container">
			
				<p class="top-link-footer"><a href="#top">Go to Top</a></p>
				<p>&copy; MINHAZ THEME.</p>
			
			</div> <!-- end container -->
			
		</div> <!-- end copyright-container -->
		
	</footer>


	<!-- JavaScript -->
	<script src="<?php echo THEMEROOT; ?>/js/jquery-1.8.2.min.js"></script>
	<script src="<?php echo THEMEROOT; ?>/js/scripts.js"></script>
<?php wp_footer(); ?>
</body>
</html>